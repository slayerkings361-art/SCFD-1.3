/*
 * Smart Car Flood Defense v1.0 — ESP32 + A02YYUW (UART ultrasonic)
 *
 * Hardware wiring:
 *   A02YYUW VCC  -> ESP32 3V3  (verify your module's voltage specifications)
 *   A02YYUW GND  -> ESP32 GND
 *   A02YYUW TX   -> ESP32 GPIO16 (UART2 RX)
 *   A02YYUW RX   -> leave unconnected for stable, processed output (module dependent)
 *   3.3V active buzzer control or transistor driver -> GPIO25
 *
 * Mount sensor facing DOWN, at a calibrated height above dry ground.
 * Water level (cm) = mount height - distance to water (cm).
 * Never connect a 12V vehicle supply directly to the ESP32.
 * Use a fused automotive-rated buck converter and waterproof enclosure.
 */
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <time.h>
#include "ca_cert.h"

// EDIT THESE SETTINGS BEFORE UPLOADING:
const char* WIFI_SSID = "REPLACE_WITH_WIFI_NAME";
const char* WIFI_PASSWORD = "REPLACE_WITH_WIFI_PASSWORD";
const char* FUNCTION_URL = "https://asia-southeast1-YOUR_PROJECT.cloudfunctions.net/ingestTelemetry";
const char* DEVICE_TOKEN = "REPLACE_WITH_LONG_RANDOM_DEVICE_SECRET";

constexpr int SENSOR_UART_RX = 16;
constexpr int BUZZER_PIN = 25;
constexpr float SENSOR_HEIGHT_CM = 60.0f;  // CALIBRATE THIS TO YOUR ACTUAL MOUNT
constexpr float WARNING_CM = 10.0f;
constexpr float DANGER_CM = 25.0f;
constexpr unsigned long UPLOAD_INTERVAL_MS = 8000;
constexpr unsigned long RECONNECT_INTERVAL_MS = 15000;
constexpr unsigned long SENSOR_TIMEOUT_MS = 10000;

HardwareSerial sensorSerial(2);
float latestLevelCm = 0.0f;
bool everReadSensor = false;
unsigned long lastValidSensorMs = 0;
unsigned long lastUploadMs = 0;
unsigned long lastReconnectMs = 0;
uint8_t serialFrame[4] = {0};
int frameIndex = 0;

bool sampleDistanceCm(float &distanceCm) {
  while(sensorSerial.available()) {
    const uint8_t nextByte = (uint8_t)sensorSerial.read();
    if(frameIndex == 0) {
      if(nextByte != 0xFF)continue;
      serialFrame[0] = nextByte;
      frameIndex = 1;
      continue;
    }
    serialFrame[frameIndex++] = nextByte;
    if(frameIndex < 4) continue;
    frameIndex = 0;
    const uint8_t sum = (uint8_t)(serialFrame[0] + serialFrame[1] + serialFrame[2]);
    if(sum != serialFrame[3]) continue;
    const uint16_t distanceMm = ((uint16_t)serialFrame[1] << 8) | serialFrame[2];
    // A02YYUW operating range depends on version; discard implausible values.
    if(distanceMm < 30 || distanceMm > 4500) continue;
    distanceCm = distanceMm / 10.0f;
    return true;
  }
  return false;
}

bool sensorFresh() {
  return everReadSensor && (millis() - lastValidSensorMs) < SENSOR_TIMEOUT_MS;
}
void updateBuzzer() {
  const unsigned long tick = millis();
  bool on = false;
  if(!sensorFresh()) {
    // Two short beeps means that sensor readings are unavailable.
    const unsigned long p = tick % 4500;
    on = (p < 130) || (p >= 240 && p < 370);
  } else if(latestLevelCm >= DANGER_CM) {
    on = (tick % 750) < 430; // repeated urgent beep
  } else if(latestLevelCm >= WARNING_CM) {
    on = (tick % 2200) < 200; // gentle warning beep
  }
  digitalWrite(BUZZER_PIN, on ? HIGH : LOW);
}
void connectWifi() {
  if(WiFi.status()==WL_CONNECTED)return;
  if(millis() - lastReconnectMs < RECONNECT_INTERVAL_MS && lastReconnectMs != 0)return;
  lastReconnectMs = millis();
  Serial.println("Connecting Wi-Fi...");
  WiFi.begin(WIFI_SSID,WIFI_PASSWORD);
}
void uploadTelemetry(float levelCm) {
  if(WiFi.status() != WL_CONNECTED) {
    Serial.println("Offline: local buzzer remains active; upload skipped");
    return;
  }
  WiFiClientSecure client;
  client.setCACert(GOOGLE_TRUST_ROOTS); // TLS verification ENABLED; not setInsecure().
  client.setTimeout(7000);
  HTTPClient http;
  if(!http.begin(client,FUNCTION_URL)) {
    Serial.println("Could not initialize HTTPS request");return;
  }
  http.setTimeout(7000);
  http.addHeader("Content-Type","application/json");
  http.addHeader("X-Device-Token",DEVICE_TOKEN);
  String json = String("{\"deviceId\":\"car-001\",\"levelCm\":") + String(levelCm,1) +
                String(",\"wifiRssi\":") + String(WiFi.RSSI()) + String("}");
  int code = http.POST(json);
  Serial.printf("Upload: %d, %.1f cm\n",code,levelCm);
  if(code<0) Serial.println(http.errorToString(code));
  http.end();
}

void setup() {
  Serial.begin(115200);
  sensorSerial.begin(9600, SERIAL_8N1, SENSOR_UART_RX, -1);
  pinMode(BUZZER_PIN,OUTPUT);
  digitalWrite(BUZZER_PIN,LOW);
  WiFi.mode(WIFI_STA);
  connectWifi();
  configTime(8 * 3600, 0, "pool.ntp.org", "time.google.com");
  Serial.println("Smart Car Flood Defense starting. Do not use as sole safety system.");
}
void loop() {
  float sensorDistanceCm;
  if(sampleDistanceCm(sensorDistanceCm)) {
    latestLevelCm = constrain(SENSOR_HEIGHT_CM - sensorDistanceCm,0.0f,60.0f);
    lastValidSensorMs = millis();
    everReadSensor = true;
  }
  updateBuzzer();
  connectWifi();
  if(sensorFresh() && millis() - lastUploadMs >= UPLOAD_INTERVAL_MS) {
    lastUploadMs = millis();
    uploadTelemetry(latestLevelCm);
  }
  delay(30);
}
