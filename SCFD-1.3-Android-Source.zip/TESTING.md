# SCFD 1.3 Test plan

1. Run `gradle assembleDebug` in Android Studio/GitHub Actions (compilation test).
2. Install app on Android 8+; if there is a signature mismatch with an experimental 1.2 APK, uninstall old APK.
3. Android 13+: allow notification permission. Open Settings and enable Alert sounds.
4. Tap `Start background test`; immediately lock device. Check persistent service notification and Warning at +8s, Danger at +16s, Safe at +26s. Confirm red Danger notification and 6.4s siren. Stop test from notification action; repeat to verify no duplicate timers.
5. Repeat while phone is minimized/swiped from recents (OEM-dependent), DND on, and with media/alarm volume low; note any device-specific restrictions.
6. Disable sound setting and rerun: notifications should show, but no local audio should play.
7. Confirm sample events are clearly marked DEMO / simulated.
8. Configure Firebase credentials and register authorized native token. Send data-only FCM message `{deviceId:car-001,status:danger,levelCm:32}` at Android priority HIGH. Confirm notification and channel ringtone while app closed. Confirm unknown device/status/level messages are ignored.
9. Verify ESP32 hardware independently; simulate flood signal, then test offline/wifi-loss path and buzzer fail-safe.

Not completed here: Gradle compilation (no Android SDK), actual phone installation, background playback, and FCM delivery. These must be completed before research claims.
