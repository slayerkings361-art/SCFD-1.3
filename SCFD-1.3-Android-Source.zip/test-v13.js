'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const nodes=new Map();
class El {
 constructor(){this.textContent='';this.innerHTML='';this.style={};this.dataset={};this.hidden=false;this.value='';this.checked=true;this.listeners={};this.classList={toggle(){}};}
 addEventListener(k,h){this.listeners[k]=h;}
 click(){this.listeners.click?.({target:this});}
 setAttribute(){}removeAttribute(){}
}
const get=id=>{if(!nodes.has(id))nodes.set(id,new El());return nodes.get(id)};
const views=['dashboard','alerts','settings'].map(v=>Object.assign(new El(),{dataset:{view:v}}));
const levels=[4,16,32].map(v=>Object.assign(new El(),{dataset:{level:String(v)}}));
const sounds=['safe','warning','danger'].map(v=>Object.assign(new El(),{dataset:{testSound:v}}));
const sections=['dashboard','alerts','settings'].map(v=>new El());
const audio=[];
function Audio(url){this.url=url;this.pause=()=>{};this.play=()=>{audio.push(url);return Promise.resolve()};}
const ls=new Map();
const localStorage={getItem:k=>ls.has(k)?ls.get(k):null,setItem:(k,v)=>ls.set(k,String(v)),removeItem:k=>ls.delete(k)};
const document={readyState:'complete',addEventListener(){},getElementById:get,querySelectorAll:k=>({
  '[data-view]':views,'[data-level]':levels,'[data-test-sound]':sounds,'.view':sections
})[k] || []};
const native=[];
const window={location:{hash:'',protocol:'file:'},scrollTo(){},addEventListener(){},AndroidAlerts:{alertLevel(...args){native.push(args)},requestNotifications(){native.push(['permission'])},startBackgroundDemo(...args){native.push(['background-start',...args])},stopBackgroundDemo(){native.push(['background-stop'])},requestFcmToken(){native.push(['token-request'])},readBackgroundDemoEvents(){return '[]'}}};
let fakeNow=Date.now();
class ClockDate extends Date {static now(){return fakeNow;}}
const ctx={document,window,localStorage,location:window.location,navigator:{},globalThis:null,
  Math,Date:ClockDate,Number,JSON,console,Audio,Notification:{permission:'default'},clearTimeout(){},setTimeout(){},clearInterval(){},setInterval(){return 1}};
ctx.globalThis=ctx;
vm.runInNewContext(fs.readFileSync(__dirname+'/app/src/main/assets/app.js','utf8'),ctx);
// Native bridge dispatch after each level crossing.
levels[1].click();levels[2].click();levels[0].click();
assert.deepEqual(native.map(x=>x[0]),['warning','danger','safe']);
assert.equal(native[0][2],'demo');
assert.equal(native[1][3],true);
// Immediate DANGER re-entry, previously suppressed by 30-second per-level cooldown.
levels[2].click(); // SAFE -> DANGER
assert.equal(native.length,4);
levels[2].click(); // Unchanged DANGER: no duplicate
assert.equal(native.length,4);
levels[0].click(); // DANGER -> SAFE
assert.equal(native.length,5);
levels[2].click(); // SAFE -> DANGER again, MUST alert immediately
assert.equal(native.at(-1)[0],'danger');
assert.equal(native.length,6);
levels[0].click(); // Restore SAFE
assert.equal(native.length,7);
assert.equal(audio.length,0,'No double audio when native bridge exists');
// Button sound tests do not create local alert history.
let count=Number(get('historyTotal').textContent);
sounds[0].click();sounds[1].click();sounds[2].click();
assert.deepEqual(native.slice(7).map(x=>x[0]),['safe','warning','danger']);
assert.equal(Number(get('historyTotal').textContent),count);
assert.equal(native.at(-1)[4],true);
// Muting does not suppress native notification when a level changes.
get('soundEnabled').listeners.change({target:{checked:false}});
fakeNow+=31000;
levels[1].click();
assert.equal(native.at(-1)[3],false);
count=native.length;
sounds[2].click();assert.equal(native.length,count,'Muted test does not run');
get('enableNotifications').click();assert.equal(native.at(-1)[0],'permission');
console.log('PASS: status transitions, repeated DANGER entry, 3 test buttons, mute, notifications.');

// Native background test control + token UI wiring.
get('startBackgroundDemo').click();
assert.equal(native.at(-1)[0], 'background-start');
assert.equal(native.at(-1)[1], false, 'Mute follows sound toggle');
get('stopBackgroundDemo').click();
assert.equal(native.at(-1)[0], 'background-stop');
get('requestFcmToken').click();
assert.equal(native.at(-1)[0], 'token-request');
window.scfdReceiveFcmToken('TOKEN_REDACTED','');
assert.equal(get('nativeFcmToken').value,'TOKEN_REDACTED');
console.log('PASS: v1.3 background demo controls and native FCM token bridge.');
