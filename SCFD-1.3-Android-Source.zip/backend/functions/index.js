'use strict';
const { onRequest } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getDatabase } = require('firebase-admin/database');
const { getMessaging } = require('firebase-admin/messaging');
const crypto = require('node:crypto');

initializeApp();
const DEVICE_SECRET = defineSecret('DEVICE_TOKEN');
const DEVICE_ID = 'car-001';
const WARNING_CM = 10;
const DANGER_CM = 25;

function sameSecret(a, b) {
  if (!a || !b) return false;
  const da = crypto.createHash('sha256').update(String(a)).digest();
  const db = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(da, db);
}
function statusFor(levelCm) {
  if (levelCm >= DANGER_CM) return 'danger';
  if (levelCm >= WARNING_CM) return 'warning';
  return 'safe';
}
function messageFor(status, cm) {
  if (status === 'danger') return `Critical flood danger! Water level is ${cm.toFixed(1)} cm. Avoid floodwater.`;
  if (status === 'warning') return `Flood warning. Water level reached ${cm.toFixed(1)} cm. Check your vehicle.`;
  return `Water level returned to safe (${cm.toFixed(1)} cm).`;
}
async function sendWarnings(db, status, levelCm) {
  const subscriptions = await db.ref(`devices/${DEVICE_ID}/subscribers`).get();
  const entries = [];
  subscriptions.forEach(child => {
    const record = child.val();
    if (record && typeof record.token === 'string' && record.token) entries.push({uid:child.key,token:record.token});
  });
  if (!entries.length) return;
  const title = status === 'danger' ? '🚨 CRITICAL FLOOD DANGER' : status === 'warning' ? '⚠️ FLOOD WARNING' : '✓ WATER SAFE';
  const message = messageFor(status,levelCm);
  for(let index=0;index<entries.length;index+=500) {
    const chunk = entries.slice(index,index+500);
    const reply = await getMessaging().sendEachForMulticast({
      tokens:chunk.map(e=>e.token),
      data:{title,message,status,deviceId:DEVICE_ID,levelCm:String(levelCm)},
      webpush:{headers:{Urgency:'high',TTL:'3600'}},
      android:{priority:'high',ttl:3600*1000}
    });
    for(let i=0;i<reply.responses.length;i++) {
      const response=reply.responses[i];
      if(response.success)continue;
      const code=response.error?.code;
      if(code==='messaging/registration-token-not-registered'||code==='messaging/invalid-registration-token') {
        // Prevent deleting a newly replaced subscription in a concurrent request.
        const ref=db.ref(`devices/${DEVICE_ID}/subscribers/${chunk[i].uid}`);
        await ref.transaction(current=>current?.token===chunk[i].token?null:undefined);
      }
    }
  }
}

exports.ingestTelemetry = onRequest(
  {region:'asia-southeast1',secrets:[DEVICE_SECRET],timeoutSeconds:30,invoker:'public',cors:false},
  async(req,res) => {
    if (req.method!=='POST') {res.set('Allow','POST').status(405).json({error:'POST required'});return;}
    if(!sameSecret(req.get('x-device-token'),DEVICE_SECRET.value())) {res.status(401).json({error:'Unauthorized device'});return;}
    const {deviceId,levelCm,wifiRssi} = req.body || {};
    if(deviceId!==DEVICE_ID || typeof levelCm !== 'number' || !Number.isFinite(levelCm) || levelCm<0 || levelCm>60) {
      res.status(400).json({error:'Expected deviceId car-001 and levelCm from 0 to 60'});return;
    }
    if(wifiRssi!==undefined && (typeof wifiRssi!=='number' || !Number.isFinite(wifiRssi)||wifiRssi < -130||wifiRssi>0)) {
      res.status(400).json({error:'Invalid Wi-Fi signal value'});return;
    }
    try {
      const db=getDatabase();
      const timestampMs=Date.now();
      const normalized=Math.round(levelCm*10)/10;
      const status=statusFor(normalized);
      const ref=db.ref(`devices/${DEVICE_ID}/latest`);
      const transaction=await ref.transaction(current=>({
        deviceId:DEVICE_ID,levelCm:normalized,status,
        timestampMs,wifiRssi:wifiRssi ?? null
      }));
      if(!transaction.committed){res.status(503).json({error:'Could not save telemetry'});return;}
      // Keep an atomic marker so repeated telemetry in the same band does not
      // create duplicate events or push notifications.
      const transitionRef=db.ref(`devices/${DEVICE_ID}/lastStatus`);
      const transition=await transitionRef.transaction(oldStatus => oldStatus===status ? undefined : status);
      if(transition.committed) {
        const eventRef=db.ref(`devices/${DEVICE_ID}/events`).push();
        const event={status,levelCm:normalized,timestampMs,message:messageFor(status,normalized)};
        await eventRef.set(event);
        try {await sendWarnings(db,status,normalized);} catch(e) {console.error('FCM delivery error:',e);}
      }
      res.status(200).json({ok:true,levelCm:normalized,status,timestampMs,transitioned:transition.committed});
    } catch(err) {
      console.error('Telemetry processing error:',err);
      res.status(500).json({error:'Server error'});
    }
  }
);
