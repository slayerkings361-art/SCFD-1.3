package ph.smartcar.flooddefense;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

/** Data-only FCM delivery for REAL ESP32 events. Needs Firebase configuration. */
public final class FloodMessagingService extends FirebaseMessagingService {
    @Override public void onMessageReceived(RemoteMessage message) {
        Map<String,String> data=message.getData();
        if (!"car-001".equals(data.get("deviceId"))) return;
        String status=data.get("status");
        if (!("danger".equals(status) || "warning".equals(status) || "safe".equals(status))) return;
        try {
            double cm=Double.parseDouble(data.get("levelCm"));
            if (!Double.isFinite(cm) || cm<0 || cm>60) return;
            FloodAlerts.configure(this);
            FloodAlerts.notifyLive(this,status,cm);
        } catch (RuntimeException ignored) {
            // Ignore malformed telemetry; never accept arbitrary notification text.
        }
    }
    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        // Intentionally not sent to a public URL or logged.
        // Secure enrollment with Firebase Auth + authorized account is required.
    }
}
