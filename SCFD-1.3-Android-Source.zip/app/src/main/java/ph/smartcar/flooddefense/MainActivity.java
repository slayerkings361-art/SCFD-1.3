package ph.smartcar.flooddefense;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;

/** v1.3 WebView dashboard + native foreground demo + FCM receiver. */
public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FloodAlerts.configure(this);
        webView = new WebView(this);
        WebSettings settings=webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new FloodBridge(), "AndroidAlerts");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private final class FloodBridge {
        @JavascriptInterface public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
            });
        }

        @JavascriptInterface public void startBackgroundDemo(boolean soundsEnabled) {
            runOnUiThread(() -> {
                // Must be triggered via Settings while this Activity is visible.
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},4001);
                    return; // user taps Start again after granting permission
                }
                Intent demo=new Intent(MainActivity.this,BackgroundDemoService.class)
                    .setAction(BackgroundDemoService.ACTION_START)
                    .putExtra("sounds",soundsEnabled);
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(demo);
                    else startService(demo);
                } catch (RuntimeException e) {
                    android.util.Log.e("SCFD", "Could not start background demo", e);
                }
            });
        }

        @JavascriptInterface public String readBackgroundDemoEvents() {
            return getSharedPreferences("scfd_bg_demo", MODE_PRIVATE).getString("events","[]");
        }

        @JavascriptInterface public void requestFcmToken() {
            runOnUiThread(() -> {
                if (FirebaseApp.getApps(MainActivity.this).isEmpty()) {
                    deliverToken("", "Firebase not configured. Add google-services.json and rebuild.");
                    return;
                }
                try {
                    FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null)
                            deliverToken(task.getResult(), "");
                        else deliverToken("", "FCM unavailable. Check Google Play services and internet.");
                    });
                } catch (RuntimeException e) {
                    deliverToken("", "FCM could not initialize.");
                }
            });
        }

        private void deliverToken(String token, String error) {
            if (webView == null) return;
            String js="window.scfdReceiveFcmToken("+JSONObject.quote(token)+","+JSONObject.quote(error)+")";
            webView.evaluateJavascript(js, null);
        }

        @JavascriptInterface public void stopBackgroundDemo() {
            runOnUiThread(() -> stopService(new Intent(MainActivity.this,BackgroundDemoService.class)));
        }

        /** Local test sounds and statuses while Activity is visible. */
        @JavascriptInterface public void alertLevel(String status, double level,
                String source, boolean soundEnabled, boolean test) {
            if (!("safe".equals(status) || "warning".equals(status) || "danger".equals(status))) return;
            if (!("demo".equals(source) || "live".equals(source) || "test".equals(source))) return;
            if (!Double.isFinite(level) || level<0 || level>60) return;
            runOnUiThread(() -> {
                if ("live".equals(source) && !test) {
                    FloodAlerts.notifyLive(MainActivity.this,status,level);
                } else {
                    if (soundEnabled) FloodAlerts.playDemoTone(MainActivity.this,status);
                    if (!test) FloodAlerts.notifyDemo(MainActivity.this,status,level,false);
                }
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if(webView!=null) {webView.removeJavascriptInterface("AndroidAlerts");webView.destroy();}
        super.onDestroy();
    }
}
