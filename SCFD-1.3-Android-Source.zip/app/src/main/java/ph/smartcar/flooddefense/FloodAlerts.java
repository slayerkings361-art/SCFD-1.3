package ph.smartcar.flooddefense;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.util.Locale;

/** Android-owned alerts. The HTML simulator does not run in the background. */
public final class FloodAlerts {
    static final String DEMO_SERVICE_CHANNEL = "scfd_v13_demo_service";
    private static final String DEMO_EVENTS_CHANNEL = "scfd_v13_demo_events";
    private static final String LIVE_SAFE_CHANNEL = "scfd_v13_live_safe";
    private static final String LIVE_WARN_CHANNEL = "scfd_v13_live_warning";
    private static final String LIVE_DANGER_CHANNEL = "scfd_v13_live_danger";
    private static MediaPlayer currentPlayer;

    private FloodAlerts() {}

    public static void configure(Context context) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel running = new NotificationChannel(DEMO_SERVICE_CHANNEL,
                "SCFD background demo running", NotificationManager.IMPORTANCE_LOW);
        running.setSound(null, null);
        nm.createNotificationChannel(running);
        NotificationChannel events = new NotificationChannel(DEMO_EVENTS_CHANNEL,
                "SCFD demo test events", NotificationManager.IMPORTANCE_HIGH);
        events.setSound(null, null);  // Native MediaPlayer handles demo tone.
        events.enableVibration(true);
        nm.createNotificationChannel(events);
        createSoundChannel(context, nm, LIVE_SAFE_CHANNEL, "SCFD live: Safe",
                NotificationManager.IMPORTANCE_DEFAULT, R.raw.safe_chime, false);
        createSoundChannel(context, nm, LIVE_WARN_CHANNEL, "SCFD live: Warning",
                NotificationManager.IMPORTANCE_HIGH, R.raw.warning_beep, true);
        createSoundChannel(context, nm, LIVE_DANGER_CHANNEL, "SCFD live: Danger",
                NotificationManager.IMPORTANCE_HIGH, R.raw.danger_siren, true);
    }

    private static void createSoundChannel(Context ctx, NotificationManager nm, String id,
            String label, int importance, int rawId, boolean vibrate) {
        NotificationChannel channel = new NotificationChannel(id, label, importance);
        // A notification-channel tone is more reliable than webpage audio when
        // Android receives FCM while the app is not open.
        Uri tone = Uri.parse("android.resource://" + ctx.getPackageName() + "/" + rawId);
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        channel.setSound(tone, attributes);
        channel.enableVibration(vibrate);
        if (vibrate) channel.setVibrationPattern(new long[]{0,300,150,300,150,600});
        nm.createNotificationChannel(channel);
    }

    public static void playDemoTone(Context ctx, String status) {
        int tone = soundFor(status);
        if (tone < 0) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            synchronized (FloodAlerts.class) {
                if (currentPlayer != null) {
                    try { currentPlayer.stop(); } catch (Exception ignored) {}
                    currentPlayer.release();
                    currentPlayer = null;
                }
                try {
                    MediaPlayer mp = new MediaPlayer();
                    mp.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage("danger".equals(status) ? AudioAttributes.USAGE_ALARM
                                    : AudioAttributes.USAGE_NOTIFICATION_EVENT)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                    try (AssetFileDescriptor afd=ctx.getResources().openRawResourceFd(tone)) {
                        if (afd == null) throw new IllegalStateException("Audio resource unavailable");
                        mp.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    }
                    mp.setOnCompletionListener(p -> {
                        synchronized(FloodAlerts.class) { if (currentPlayer==p) currentPlayer=null; }
                        p.release();
                    });
                    mp.prepare();
                    mp.setVolume(1f,1f);
                    currentPlayer = mp;
                    mp.start();
                } catch (Exception ex) {
                    android.util.Log.e("SCFD", "Demo primary audio failed, using fallback", ex);
                    try {
                        MediaPlayer fallback=MediaPlayer.create(ctx,tone);
                        if (fallback != null) {
                            fallback.setVolume(1f,1f);
                            fallback.setOnCompletionListener(p -> {
                                synchronized(FloodAlerts.class) { if (currentPlayer==p) currentPlayer=null; }
                                p.release();
                            });
                            currentPlayer=fallback;
                            fallback.start();
                        }
                    } catch (RuntimeException error) {
                        android.util.Log.e("SCFD","Demo fallback audio failed",error);
                    }
                }
            }
        });
    }

    private static int soundFor(String status) {
        switch (status) {
            case "safe": return R.raw.safe_chime;
            case "warning": return R.raw.warning_beep;
            case "danger": return R.raw.danger_siren;
            default: return -1;
        }
    }

    public static Notification makeRunningNotification(Context ctx) {
        Intent stop = new Intent(ctx, BackgroundDemoService.class).setAction(BackgroundDemoService.ACTION_STOP);
        PendingIntent stopAction = PendingIntent.getService(ctx, 9002, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return builder(ctx, DEMO_SERVICE_CHANNEL)
                .setContentTitle("SCFD background demo test")
                .setContentText("Test running. Warning at 8s, Danger at 16s. DEMO ONLY.")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop test", stopAction)
                .build();
    }

    /** Native demo alerts: notification + optional local sound. */
    public static void notifyDemo(Context ctx, String status, double cm, boolean soundEnabled) {
        if (soundEnabled) playDemoTone(ctx, status);
        String title = "SCFD DEMO • " + status.toUpperCase(Locale.ROOT);
        String content = String.format(Locale.US,
                "Simulated water level: %.1f cm. Not a live sensor reading.", cm);
        post(ctx, DEMO_EVENTS_CHANNEL, title, content,
                3000 + ("danger".equals(status) ? 1 : "warning".equals(status) ? 2 : 3));
    }

    /** FCM: channel owns sound so notification can play while app is closed. */
    public static void notifyLive(Context ctx, String status, double cm) {
        String channel = "danger".equals(status) ? LIVE_DANGER_CHANNEL
                : "warning".equals(status) ? LIVE_WARN_CHANNEL : LIVE_SAFE_CHANNEL;
        String title = "danger".equals(status) ? "SCFD • FLOOD DANGER"
                : "warning".equals(status) ? "SCFD • Flood warning" : "SCFD • Water safe";
        String text = String.format(Locale.US,
                "ESP32 water reading: %.1f cm. Check the vehicle and avoid floodwater.", cm);
        post(ctx, channel, title, text, 4000 + ("danger".equals(status) ? 1 : "warning".equals(status) ? 2 : 3));
    }

    private static void post(Context ctx, String channel, String title, String body, int notificationId) {
        if (Build.VERSION.SDK_INT >= 33 &&
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Notification.Builder b = builder(ctx, channel)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title).setContentText(body)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true).setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setContentIntent(openApp(ctx));
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_HIGH);
        nm.notify(notificationId, b.build());
    }

    private static Notification.Builder builder(Context ctx, String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, channel)
                : new Notification.Builder(ctx);
    }

    private static PendingIntent openApp(Context ctx) {
        Intent i=new Intent(ctx,MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx,8001,i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
