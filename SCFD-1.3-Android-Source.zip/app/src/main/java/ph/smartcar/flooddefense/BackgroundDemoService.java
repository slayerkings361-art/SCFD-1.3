package ph.smartcar.flooddefense;

import android.app.Service;
import android.app.Notification;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** User-started 28-second background demo, NOT actual flood monitoring. */
public final class BackgroundDemoService extends Service {
    public static final String ACTION_START = "ph.smartcar.flooddefense.START_DEMO";
    public static final String ACTION_STOP = "ph.smartcar.flooddefense.STOP_DEMO";
    private static final int PERSISTENT_ID = 4401;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean soundEnabled=true;
    private PowerManager.WakeLock shortTestWakeLock;

    @Override public void onCreate() {
        super.onCreate();
        FloodAlerts.configure(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            handler.removeCallbacksAndMessages(null);
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.removeCallbacksAndMessages(null);
        soundEnabled = intent == null || intent.getBooleanExtra("sounds", true);
        if (shortTestWakeLock != null && shortTestWakeLock.isHeld()) shortTestWakeLock.release();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (pm != null) {
            shortTestWakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"SCFD:29sBackgroundTest");
            shortTestWakeLock.setReferenceCounted(false);
            shortTestWakeLock.acquire(31_000L); // bounded; never a permanent wakelock
        }
        Notification persistent=FloodAlerts.makeRunningNotification(this);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(PERSISTENT_ID, persistent, ServiceInfo.FOREGROUND_SERVICE_TYPE_SHORT_SERVICE);
        } else {
            startForeground(PERSISTENT_ID, persistent);
        }
        // Service owns the timer. It keeps running after Activity loses focus,
        // screen turns off, or the user swipes Activity away (device-dependent).
        handler.postDelayed(() -> emit("warning",16),8_000);
        handler.postDelayed(() -> emit("danger",32),16_000);
        handler.postDelayed(() -> emit("safe",4),26_000);
        handler.postDelayed(this::stopSelf, 29_000);
        return START_NOT_STICKY;
    }

    private void emit(String status, double cm) {
        FloodAlerts.notifyDemo(this, status, cm, soundEnabled);
        // Preserve demonstration events when the user leaves or locks the app.
        try {
            SharedPreferences prefs=getSharedPreferences("scfd_bg_demo",MODE_PRIVATE);
            JSONArray old=new JSONArray(prefs.getString("events","[]"));
            JSONObject evt=new JSONObject();
            evt.put("status",status);
            evt.put("levelCm",cm);
            evt.put("timestampMs",System.currentTimeMillis());
            evt.put("message","Android background DEMO: "+status);
            JSONArray next=new JSONArray();
            for(int i=Math.max(0,old.length()-24); i<old.length(); i++) next.put(old.get(i));
            next.put(evt);
            prefs.edit().putString("events",next.toString()).apply();
        } catch(Exception ignored) {
            // Alerts still work even if local event history cannot be written.
        }
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Do not call stopSelf: a running foreground test may continue even if
        // the UI is dismissed. OEM battery management still varies.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onTimeout(int startId) {
        stopSelf();
    }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (shortTestWakeLock != null && shortTestWakeLock.isHeld()) shortTestWakeLock.release();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
