/* Smart Car Flood Defense • working demo + Firebase live client */
(() => {
  'use strict';

  const DEVICE_ID = 'car-001';
  const WARNING_CM = 10;
  const DANGER_CM = 25;
  const OFFLINE_MS = 90000;
  const STORAGE_HISTORY = 'smartcar-demo-history-v1';
  const STORAGE_LEVEL = 'smartcar-demo-level-v1';
  const STORAGE_SOUND = 'smartcar-sounds-enabled-v1';
  const ALERT_AUDIO_FILES = {safe:'./sounds/safe_chime.wav',warning:'./sounds/warning_beep.wav',danger:'./sounds/danger_siren.wav'};
  const VERSION = '10.14.1'; // SCFD v1.3
  const $ = id => document.getElementById(id);
  const getStatus = level => level >= DANGER_CM ? 'danger' : level >= WARNING_CM ? 'warning' : 'safe';
  const isFiniteNumber = x => typeof x === 'number' && Number.isFinite(x);
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x));
  const escapeHtml = val => String(val).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const formatTime = ms => new Date(ms).toLocaleTimeString('en-PH', {hour:'numeric',minute:'2-digit'});
  const formatDate = ms => new Date(ms).toLocaleDateString('en-PH', {month:'short',day:'numeric'});

  function storedHistory() {
    try {
      const val = JSON.parse(localStorage.getItem(STORAGE_HISTORY) || '[]');
      if (!Array.isArray(val)) return [];
      return val.filter(x => x && ['safe','warning','danger'].includes(x.status) && isFiniteNumber(x.timestampMs) && isFiniteNumber(x.levelCm)).slice(0, 75);
    } catch { return []; }
  }
  function storedLevel() {
    try { const saved = localStorage.getItem(STORAGE_LEVEL); return saved === null ? 4 : clamp(Number(saved), 0, 60); }
    catch { return 4; }
  }

  const state = {
    view: 'dashboard', mode: 'demo', demoLevel: storedLevel(), level: storedLevel(),
    status: getStatus(storedLevel()), telemetryTimestamp: Date.now(), connected: false,
    history: storedHistory(), trend: Array(17).fill(0).map((_, i) => Math.max(0, storedLevel() - 2 + 2 * Math.sin(i / 3))),
    autoTimer: null, toastTimer: null, firebase: null, firebaseUnsubs: [], messaging: null,
    swRegistration: null, email: null, soundEnabled: localStorage.getItem(STORAGE_SOUND) !== 'false',
    lastLiveStatus: null, audioPlayer: null
  };

  function showToast(message, severity='safe') {
    const node = $('toast');
    node.textContent = message;
    node.className = `toast ${severity}`;
    node.hidden = false;
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => node.hidden = true, 4800);
  }
  function addDemoEvent(status, levelCm, timestampMs) {
    const messages = {
      safe: 'Water level returned to safe',
      warning: 'Flood warning: water rising',
      danger: 'Critical flood danger detected'
    };
    state.history.unshift({ status, levelCm, timestampMs, message: messages[status] });
    state.history = state.history.slice(0, 75);
    try { localStorage.setItem(STORAGE_HISTORY, JSON.stringify(state.history)); } catch {}
  }
  async function sendLocalNotification(status, levelCm) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const title = status === 'danger' ? '🚨 CRITICAL: Flood danger!' : '⚠️ Flood warning';
    const body = `Water level: ${Number(levelCm).toFixed(1)} cm • Smart Car Flood Defense`;
    const options = { body, icon: './icons/icon-192.png', tag: `smartcar-${status}` };
    try {
      if (state.swRegistration) await state.swRegistration.showNotification(title, options);
      else new Notification(title, options);
    } catch (e) { console.warn('Notification could not be shown:', e); }
  }

  // Foreground audio always uses local, bundled sound files. Android can use native audio
  // and notifications via a restricted JavaScript bridge; browsers use HTMLAudioElement.
  function hasAndroidAlerts() {
    return !!(window.AndroidAlerts && typeof window.AndroidAlerts.alertLevel === 'function');
  }
  function playBrowserSound(status) {
    const source = ALERT_AUDIO_FILES[status];
    if (!source || typeof Audio === 'undefined') return;
    try {
      if (state.audioPlayer) {state.audioPlayer.pause();state.audioPlayer.currentTime=0;}
      state.audioPlayer = new Audio(source);
      state.audioPlayer.preload = 'auto';
      state.audioPlayer.volume = status === 'safe' ? .55 : status === 'warning' ? .85 : 1;
      const playing = state.audioPlayer.play();
      if (playing && typeof playing.catch === 'function') playing.catch(err => {
        console.warn('Sound blocked by browser or phone:',err);
        $('soundHelp').textContent='Audio blocked by this phone. Test the sound and check Media/Alarm volume and Do Not Disturb settings.';
      });
    } catch(err) {console.warn('Unable to play alert sound:',err);}
  }
  function statusAlert(status, levelCm, source, test=false) {
    if (!['safe','warning','danger'].includes(status)) return;
    if (!state.soundEnabled && test) {
      showToast('Turn on Alert sounds first.','offline'); return;
    }
    // Every new transition, especially re-entry into DANGER, must alert.
    // updateDemoLevel() and the live listener already ignore unchanged statuses.
    if (hasAndroidAlerts()) {
      try {window.AndroidAlerts.alertLevel(status,Number(levelCm),source,!!state.soundEnabled,!!test);return;}
      catch (err) {console.warn('Native alert failed, trying browser:',err);}
    }
    if (state.soundEnabled) playBrowserSound(status);
    // Browser notification support requires HTTPS/localhost, permission, and is not
    // the same as native Android push. Status changes are also recorded in the app.
    if (!test && source==='demo' && status!=='safe') sendLocalNotification(status,levelCm);
  }
  function testAlert(status) {
    const level = status === 'safe' ? 4 : status === 'warning' ? 16 : 32;
    statusAlert(status,level,'test',true);
    if(state.soundEnabled) showToast(`${status.toUpperCase()} sound test`,status);
  }

  function updateDemoLevel(rawLevel, record=true) {
    const level = clamp(Number(rawLevel), 0, 60);
    if (!Number.isFinite(level) || state.mode !== 'demo') return;
    const previousStatus = state.status;
    state.demoLevel = level;
    state.level = level;
    state.status = getStatus(level);
    state.telemetryTimestamp = Date.now();
    state.trend.push(level);
    state.trend = state.trend.slice(-22);
    try { localStorage.setItem(STORAGE_LEVEL, String(level)); } catch {}
    if (record && previousStatus !== state.status) {
      addDemoEvent(state.status, level, state.telemetryTimestamp);
      const label = state.status === 'safe' ? 'Water level is back to safe.' : state.status === 'warning' ? 'Warning: water level reached 10 cm!' : 'Danger: water level reached 25 cm!';
      showToast(label, state.status);
      statusAlert(state.status, level, 'demo');
    }
    render();
  }

  // Pull notifications created by native Android while the WebView was paused.
  function refreshNativeBackgroundHistory() {
    if (!(window.AndroidAlerts && typeof window.AndroidAlerts.readBackgroundDemoEvents === 'function')) return;
    try {
      const events = JSON.parse(window.AndroidAlerts.readBackgroundDemoEvents());
      if (!Array.isArray(events)) return;
      const saved = storedHistory();
      const keys = new Set(saved.map(e => `${e.timestampMs}-${e.status}`));
      let latest = null;
      for (const e of events) {
        if (!e || !['safe','warning','danger'].includes(e.status) ||
            !isFiniteNumber(e.levelCm) || !isFiniteNumber(e.timestampMs)) continue;
        const key = `${e.timestampMs}-${e.status}`;
        if (!keys.has(key)) {
          keys.add(key);
          saved.push({status:e.status,levelCm:e.levelCm,timestampMs:e.timestampMs,
                      message:`BACKGROUND DEMO: ${e.status.toUpperCase()}`});
        }
        if (!latest || e.timestampMs > latest.timestampMs) latest = e;
      }
      saved.sort((a,b) => b.timestampMs-a.timestampMs);
      localStorage.setItem(STORAGE_HISTORY,JSON.stringify(saved.slice(0,75)));
      if (state.mode === 'demo') {
        state.history = saved.slice(0,75);
        const lastNativeSync = Number(localStorage.getItem('scfd-bg-last-synced') || 0);
        if (latest && latest.timestampMs > lastNativeSync) {
          state.demoLevel = latest.levelCm;
          state.level = latest.levelCm;
          state.status = getStatus(latest.levelCm);
          state.telemetryTimestamp = latest.timestampMs;
          state.trend.push(latest.levelCm);
          state.trend = state.trend.slice(-22);
          localStorage.setItem(STORAGE_LEVEL,String(latest.levelCm));
          localStorage.setItem('scfd-bg-last-synced',String(latest.timestampMs));
        }
        render();
      }
    } catch(e) { console.warn('Could not sync Android background demo history:',e); }
  }

  function resetLiveReadings() {
    state.level = null;
    state.status = 'offline';
    state.telemetryTimestamp = null;
    state.connected = false;
    state.history = [];
    state.trend = [];
    state.lastLiveStatus = null;
  }
  async function setMode(mode) {
    if (mode !== 'demo' && mode !== 'live') return;
    if (state.autoTimer) stopAutoSimulation();
    if (mode === state.mode) return;
    if (state.firebase) await disconnectFirebase(false);
    state.mode = mode;
    if (mode === 'demo') {
      state.level = state.demoLevel;
      state.status = getStatus(state.demoLevel);
      state.telemetryTimestamp = Date.now();
      state.history = storedHistory();
      state.trend = Array(18).fill(state.demoLevel);
    } else resetLiveReadings();
    render();
  }

  function isOffline() {
    return state.mode === 'live' && (!state.connected || !state.telemetryTimestamp || Date.now() - state.telemetryTimestamp > OFFLINE_MS);
  }
  function shownStatus() { return isOffline() ? 'offline' : state.status; }

  function render() {
    const live = state.mode === 'live';
    const risk = shownStatus();
    const levelText = state.level === null ? '--' : Number(state.level).toFixed(1);
    $('levelValue').textContent = levelText;
    $('statLevel').textContent = levelText;
    $('sliderLevel').textContent = state.demoLevel.toFixed(1);
    $('levelSlider').value = String(state.demoLevel);
    $('gaugeMessage').textContent = risk === 'offline' ? 'Reading unavailable / stale' : risk === 'danger' ? 'Critical water level' : risk === 'warning' ? 'Water level is rising' : 'Water level is normal';
    const progress = state.level === null ? 0 : clamp(state.level / 60, 0, 1);
    const ring = $('gaugeProgress');
    ring.style.strokeDashoffset = String(628.319 * (1 - progress));
    ring.style.stroke = risk === 'danger' ? '#ff6b80' : risk === 'warning' ? '#ffc267' : risk === 'offline' ? '#8fa2be' : '#55e2f7';
    const conditions = {
      safe: ['✓', 'Safe level', 'Water level is below the warning threshold. Your vehicle is currently in the safe zone.'],
      warning: ['!', 'Warning level', 'Water is rising. Check your vehicle location and prepare to move to safer ground.'],
      danger: ['!', 'Danger level', 'Potential flood danger. Do not enter floodwater. Follow local safety guidance.'],
      offline: ['?', 'Sensor offline', 'Current readings are unavailable or outdated. Check the ESP32, Wi-Fi, and power.']
    };
    $('conditionIcon').textContent = conditions[risk][0];
    $('conditionTitle').textContent = conditions[risk][1];
    $('conditionCopy').textContent = conditions[risk][2];
    $('riskWord').textContent = risk.toUpperCase();
    $('riskText').textContent = {
      safe:'No flood threat detected at the sensor.',
      warning:'Rising water requires attention.',
      danger:'Critical water level detected.',
      offline:'Live sensor reading unavailable.'
    }[risk];
    $('riskSignal').textContent = {safe:'● LOW RISK',warning:'● ELEVATED',danger:'● HIGH RISK',offline:'● UNKNOWN'}[risk];
    $('riskArt').textContent = {safe:'◈',warning:'⚠',danger:'⚠',offline:'⌁'}[risk];
    $('protectionLabel').textContent = risk === 'offline' ? 'UNAVAILABLE' : risk === 'safe' ? 'MONITORING' : 'ALERT ACTIVE';
    $('statusCard').className = `status-card status-${risk}`;
    const last = state.telemetryTimestamp ? formatTime(state.telemetryTimestamp) : '--:--';
    $('lastUpdated').textContent = state.telemetryTimestamp ? `Last update: ${last}` : 'Awaiting first update';
    $('statTime').textContent = last;
    $('statTimeNote').textContent = isOffline() ? 'Offline or stale' : live ? 'Real sensor update' : 'Demo sensor update';
    $('statWaterNote').textContent = risk === 'offline' ? 'Sensor unavailable' : risk === 'safe' ? 'Within safe range' : risk === 'warning' ? 'Above warning threshold' : 'Above danger threshold';
    $('heroSignal').textContent = live ? (isOffline() ? 'OFFLINE' : 'LIVE') : 'DEMO';
    $('sourceBadge').textContent = live ? (isOffline() ? 'NO CURRENT DATA' : 'ESP32 CONNECTED') : 'SIMULATION ACTIVE';
    $('connectionTitle').textContent = live ? (isOffline() ? 'Device offline' : 'ESP32 connected') : 'Demo simulation';
    $('connectionSub').textContent = live ? (isOffline() ? 'No recent sensor data' : 'Receiving cloud updates') : 'No physical device connected';
    $('connectionDot').className = `connection-dot ${live ? (isOffline() ? 'offline-dot' : '') : 'demo-dot'}`;
    $('modeChip').className = `mode-chip ${live ? 'live' : ''}`;
    $('modeChip').innerHTML = `<span class="mini-dot"></span> ${live ? 'LIVE MODE' : 'DEMO MODE'}`;
    $('monitoringState').className = `monitoring-tag ${live ? (isOffline() ? 'offline' : 'online') : ''}`;
    $('monitoringState').innerHTML = `<span class="pulse-dot"></span> ${live ? (isOffline() ? 'Device offline / no data' : 'Receiving live updates') : 'Simulated data'}`;
    $('sidebarDevice').textContent = `Car 001 • ${live ? (isOffline() ? 'Offline' : 'Live') : 'Demo'}`;
    $('deviceMode').textContent = live ? (isOffline() ? 'NO LIVE READING' : 'ESP32 LIVE') : 'SIMULATED';
    $('demoStrip').hidden = live;
    $('demoSettings').hidden = live;
    $('liveSettings').hidden = !live;
    $('demoModeButton').classList.toggle('active', !live);
    $('liveModeButton').classList.toggle('active', live);
    renderChart();
    renderAlerts();
  }

  function renderChart() {
    const svg = $('trendChart');
    const values = state.trend.length ? state.trend : [0];
    const maxY = 60, left = 37, right = 706, top = 8, bottom = 198;
    const py = level => bottom - clamp(level, 0, maxY) / maxY * (bottom - top);
    const px = i => left + i / Math.max(1,values.length - 1) * (right - left);
    const points = values.map((val,i) => `${px(i).toFixed(1)},${py(val).toFixed(1)}`).join(' ');
    const fillPath = `${values.map((val,i) => `${i===0?'M':'L'}${px(i).toFixed(1)} ${py(val).toFixed(1)}`).join(' ')} L${px(values.length-1).toFixed(1)} ${bottom} L${left} ${bottom} Z`;
    const rows = [0,15,30,45,60].map(n => `<line x1="${left}" x2="${right}" y1="${py(n)}" y2="${py(n)}" stroke="#ecf1f8" stroke-width="1"/><text x="${left-11}" y="${py(n)+4}" font-size="11" text-anchor="end" fill="#a5b1c1">${n}</text>`).join('');
    const guide = (n, color, label) => `<line x1="${left}" x2="${right}" y1="${py(n)}" y2="${py(n)}" stroke="${color}" stroke-dasharray="5 7" stroke-width="1.5"/><text x="${right-3}" y="${py(n)-5}" font-size="10" text-anchor="end" fill="${color}">${label}</text>`;
    const lastX = px(values.length-1), lastY = py(values[values.length-1]);
    svg.innerHTML = `<defs><linearGradient id="areaFade" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#4a8fff" stop-opacity=".28"/><stop offset="100%" stop-color="#4a8fff" stop-opacity=".015"/></linearGradient></defs>${rows}${guide(WARNING_CM,'#eeb052','WARN')}${guide(DANGER_CM,'#e9828a','DANGER')}<path d="${fillPath}" fill="url(#areaFade)"/><polyline points="${points}" fill="none" stroke="#477ff4" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${lastX}" cy="${lastY}" r="5.5" fill="#477ff4" stroke="white" stroke-width="3"/>`;
  }

  function renderAlerts() {
    const eventView = state.history.slice().sort((a,b) => b.timestampMs - a.timestampMs);
    const sample = eventView.slice(0, 3);
    function alertHtml(event) {
      const status = ['safe','warning','danger','offline'].includes(event.status) ? event.status : 'offline';
      const defaults = {safe:'Returned to safe level',warning:'Flood warning',danger:'Critical flood danger',offline:'Sensor offline'};
      const icon = {safe:'✓',warning:'!',danger:'!',offline:'?'}[status];
      const msg = escapeHtml(event.message || defaults[status]);
      const level = isFiniteNumber(event.levelCm) ? `${event.levelCm.toFixed(1)} cm` : 'No reading';
      const t = isFiniteNumber(event.timestampMs) ? event.timestampMs : Date.now();
      return `<article class="alert-entry ${status}"><span class="alert-marker">${icon}</span><div><h3>${msg}</h3><p>${escapeHtml(level)} • ${escapeHtml(formatDate(t))}</p></div><time datetime="${new Date(t).toISOString()}">${escapeHtml(formatTime(t))}</time></article>`;
    }
    const empty = '<div class="empty-list"><strong>No flood alerts yet</strong>When the water-level status changes, it will show up here.</div>';
    $('recentAlerts').innerHTML = sample.length ? sample.map(alertHtml).join('') : empty;
    $('allAlerts').innerHTML = eventView.length ? eventView.map(alertHtml).join('') : empty;
    $('historyTotal').textContent = String(eventView.length);
    $('historyDanger').textContent = String(eventView.filter(e => e.status==='danger').length);
    $('historyLast').textContent = eventView.length ? formatDate(eventView[0].timestampMs) : 'None';
    $('navCount').textContent = String(Math.min(eventView.length,99));
    $('bellDot').hidden = eventView.length===0;
    $('clearDemoHistory').hidden = state.mode==='live';
  }

  function gotoView(view) {
    if (!['dashboard','alerts','settings'].includes(view)) return;
    state.view = view;
    document.querySelectorAll('.view').forEach(el => el.classList.toggle('current', el.id === `view-${view}`));
    document.querySelectorAll('[data-view]').forEach(el => {
      const active = el.dataset.view === view;
      el.classList.toggle('active',active);
      if (active) el.setAttribute('aria-current','page');
      else el.removeAttribute('aria-current');
    });
    $('crumbTitle').textContent = {dashboard:'OVERVIEW',alerts:'ALERT HISTORY',settings:'SETTINGS'}[view];
    window.scrollTo({top:0,behavior:'auto'});
  }
  function stopAutoSimulation() {
    clearInterval(state.autoTimer);
    state.autoTimer = null;
    $('autoSimToggle').checked = false;
  }
  function startAutoSimulation() {
    if (state.mode !== 'demo') return;
    clearInterval(state.autoTimer);
    state.autoTimer = setInterval(() => {
      const shift = (Math.random() - .36) * 12;
      updateDemoLevel(Math.round(clamp(state.demoLevel+shift,0,60)*2)/2);
    }, 2500);
    showToast('Automatic flood simulation started.','safe');
  }

  async function registerWorker() {
    if (!('serviceWorker' in navigator) || !['https:','http:'].includes(location.protocol)) return null;
    try {
      state.swRegistration = await navigator.serviceWorker.register('./firebase-messaging-sw.js');
      return state.swRegistration;
    } catch (err) { console.warn('Service worker registration failed:',err); return null; }
  }
  async function enableNotifications() {
    if (hasAndroidAlerts() && typeof window.AndroidAlerts.requestNotifications === 'function') {
      try {window.AndroidAlerts.requestNotifications();
        $('permissionText').textContent='Android notification permission requested. Check app notification settings.';
        showToast('Allow notifications in the phone prompt to see status alerts.');
      } catch(e) {showToast('Could not request Android notifications.','offline');}
      return;
    }
    if (!('Notification' in window)) { showToast('Notifications are not supported in this browser.','offline'); return; }
    if (!window.isSecureContext) { showToast('Notifications require HTTPS or localhost.','offline'); return; }
    try {
      const permission = await Notification.requestPermission();
      if (permission==='granted') {
        $('permissionText').textContent = 'Notifications are allowed on this browser.';
        $('enableNotifications').textContent = 'Enabled';
        await registerWorker();
        showToast('Notifications enabled. Use the simulator to test alerts.');
      } else { $('permissionText').textContent = `Notification permission: ${permission}.`; showToast('Notification permission was not granted.','offline'); }
    } catch (err) {showToast(`Notification error: ${err.message}`,'offline');}
  }
  function setFeedback(message, error=false) {
    $('firebaseFeedback').textContent = message;
    $('firebaseFeedback').style.color = error ? '#d85a6b' : '#54826c';
  }
  function validFirebaseConfig() {
    const cfg = globalThis.SMARTCAR_FIREBASE_CONFIG;
    return cfg && typeof cfg==='object' && ['apiKey','authDomain','databaseURL','projectId','messagingSenderId','appId'].every(k => !!cfg[k]);
  }

  async function connectFirebase() {
    if (!validFirebaseConfig()) { setFeedback('Firebase config missing. Edit config.js and deploy first.',true); return; }
    const email = $('emailInput').value.trim();
    const password = $('passwordInput').value;
    if (!email || !password) {setFeedback('Enter your authorized email and password.',true);return;}
    if (!window.isSecureContext || location.protocol==='file:') {setFeedback('Host this app on HTTPS or localhost to use Firebase live mode.',true);return;}
    $('connectFirebase').disabled=true;
    setFeedback('Connecting to Firebase…');
    try {
      const base = `https://www.gstatic.com/firebasejs/${VERSION}`;
      const [core, authApi, dbApi, msgApi] = await Promise.all([
        import(`${base}/firebase-app.js`), import(`${base}/firebase-auth.js`),
        import(`${base}/firebase-database.js`), import(`${base}/firebase-messaging.js`)
      ]);
      const app = core.getApps().length ? core.getApp() : core.initializeApp(globalThis.SMARTCAR_FIREBASE_CONFIG);
      const auth = authApi.getAuth(app);
      const credentials = await authApi.signInWithEmailAndPassword(auth, email, password);
      const db = dbApi.getDatabase(app);
      state.firebase = {app,auth,db,authApi,dbApi,msgApi};
      state.email=credentials.user.email;
      state.connected=false;
      $('passwordInput').value='';
      $('connectFirebase').hidden=true;
      $('disconnectFirebase').hidden=false;
      $('subscribePush').disabled = false;
      $('pushText').textContent='Connect successful. Enable notifications, then subscribe for background alerts.';
      setFeedback(`Signed in as ${state.email}. Waiting for ESP32 data…`);
      const latestRef = dbApi.ref(db,`devices/${DEVICE_ID}/latest`);
      const eventsRef = dbApi.query(dbApi.ref(db,`devices/${DEVICE_ID}/events`),dbApi.limitToLast(60));
      state.firebaseUnsubs.push(dbApi.onValue(latestRef,snapshot => {
        const val = snapshot.val();
        if (val && isFiniteNumber(val.levelCm) && isFiniteNumber(val.timestampMs) && ['safe','warning','danger'].includes(val.status)) {
          const previous = state.lastLiveStatus;
          // If the first live reading is already dangerous, notify immediately.
          if (previous !== val.status && (previous !== null || val.status !== 'safe')) {
            statusAlert(val.status, val.levelCm, 'live');
          }
          state.lastLiveStatus = val.status;
          state.level = val.levelCm;
          state.status = val.status;
          state.telemetryTimestamp=val.timestampMs;
          state.connected=true;
          state.trend.push(val.levelCm);
          state.trend=state.trend.slice(-24);
        } else resetLiveReadings();
        render();
      },err => {state.connected=false;setFeedback(`Reading denied: ${err.message}`,true);render();}));
      state.firebaseUnsubs.push(dbApi.onValue(eventsRef,snapshot => {
        state.history=[];
        snapshot.forEach(child => {
          const value = child.val();
          if (value && ['safe','warning','danger'].includes(value.status) && isFiniteNumber(value.timestampMs) && isFiniteNumber(value.levelCm)) {
            state.history.push({status:value.status,levelCm:value.levelCm,timestampMs:value.timestampMs,message:String(value.message||'').slice(0,140)});
          }
        });
        state.history=state.history.slice(-60).reverse();
        renderAlerts();
      },err => setFeedback(`History denied: ${err.message}`,true)));
      try {
        const supported = await msgApi.isSupported();
        if (supported) {
          const messaging=msgApi.getMessaging(app);
          state.messaging=messaging;
          state.firebaseUnsubs.push(msgApi.onMessage(messaging,payload => {
            const status=payload.data?.status || 'warning';
            showToast(payload.data?.message || 'Flood warning received.', status);
          }));
        } else $('pushText').textContent='This browser does not support Firebase web push.';
      } catch(e) {console.warn('Messaging not available:', e);}
      render();
    } catch(err) {setFeedback(`Connection failed: ${err.message}`,true);showToast('Could not sign in. Check config and account.','offline');}
    finally {$('connectFirebase').disabled=false;}
  }
  async function disconnectFirebase(switchToDemo=true) {
    state.firebaseUnsubs.forEach(unsub=>{try{unsub();}catch{}});
    state.firebaseUnsubs=[];
    if(state.firebase){try{await state.firebase.authApi.signOut(state.firebase.auth);}catch{}}
    state.firebase=null;
    state.messaging=null;
    state.email=null;
    $('connectFirebase').hidden=false;
    $('disconnectFirebase').hidden=true;
    $('subscribePush').disabled=true;
    $('pushText').textContent='Requires Firebase, HTTPS, and a connected device.';
    setFeedback('Disconnected from Firebase.');
    if (state.mode === 'live') resetLiveReadings();
    if(switchToDemo) setMode('demo');
    else render();
  }
  async function subscribePush() {
    if (!state.firebase || !state.messaging) {showToast('Sign in with Firebase on a supported browser first.','offline');return;}
    if (!globalThis.SMARTCAR_VAPID_KEY) {showToast('Set the public VAPID key in config.js first.','offline');return;}
    if (!('Notification' in window)) {showToast('This browser cannot receive web push.','offline');return;}
    try {
      const permission=await Notification.requestPermission();
      if(permission!=='granted'){showToast('Notifications permission denied.','offline');return;}
      const registration=state.swRegistration || await registerWorker();
      if(!registration) {showToast('Service worker requires HTTPS or localhost.','offline');return;}
      const {db,dbApi,auth,msgApi}=state.firebase;
      const token=await msgApi.getToken(state.messaging,{vapidKey:globalThis.SMARTCAR_VAPID_KEY,serviceWorkerRegistration:registration});
      if(!token) throw new Error('FCM did not return a subscription token');
      await dbApi.set(dbApi.ref(db,`devices/${DEVICE_ID}/subscribers/${auth.currentUser.uid}`),{token,updatedAt:Date.now()});
      $('subscribePush').textContent='Subscribed ✓';
      $('pushText').textContent='This browser is subscribed to ESP32 flood warnings.';
      showToast('Background flood notifications are now subscribed.');
    } catch(err) {showToast(`Push subscription failed: ${err.message}`,'offline');}
  }

  function setup() {
    $('todayDate').textContent=new Date().toLocaleDateString('en-PH',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
    document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click',()=>gotoView(button.dataset.view)));
    $('bellButton').addEventListener('click',()=>gotoView('alerts'));
    $('viewAllAlerts').addEventListener('click',()=>gotoView('alerts'));
    $('openDemoSettings').addEventListener('click',()=>gotoView('settings'));
    $('demoModeButton').addEventListener('click',()=>setMode('demo'));
    $('liveModeButton').addEventListener('click',()=>setMode('live'));
    $('levelSlider').addEventListener('input',e=>updateDemoLevel(e.target.value));
    document.querySelectorAll('[data-level]').forEach(button=>button.addEventListener('click',()=>updateDemoLevel(Number(button.dataset.level))));
    $('autoSimToggle').addEventListener('change',e => e.target.checked ? startAutoSimulation() : stopAutoSimulation());
    $('clearDemoHistory').addEventListener('click',()=>{
      if(state.mode!=='demo')return;
      state.history=[];
      try{localStorage.removeItem(STORAGE_HISTORY);}catch{}
      renderAlerts();showToast('Demo alert history cleared.');
    });
    const nativeBackground = window.AndroidAlerts && typeof window.AndroidAlerts.startBackgroundDemo === 'function';
    if (!nativeBackground) {
      $('startBackgroundDemo').disabled = true;
      $('stopBackgroundDemo').disabled = true;
      $('backgroundDemoStatus').textContent = 'Background testing requires the Android v1.3 app; it is unavailable in a browser or the old APK.';
    }
    $('startBackgroundDemo').addEventListener('click', () => {
      if (!nativeBackground) return;
      try {
        window.AndroidAlerts.startBackgroundDemo(!!state.soundEnabled);
        $('backgroundDemoStatus').textContent = 'If notifications are allowed: 8s WARNING, 16s DANGER, 26s SAFE. Lock the screen now. If prompted for permission, allow and tap Start again.';
        showToast('Android background DEMO started (subject to permission).');
      } catch(e) {showToast('Could not start background demo.','offline');}
    });
    $('stopBackgroundDemo').addEventListener('click', () => {
      if (!nativeBackground) return;
      try {
        window.AndroidAlerts.stopBackgroundDemo();
        $('backgroundDemoStatus').textContent = 'Background demo stopped.';
        showToast('Background demo stopped.');
      } catch(e) {showToast('Could not stop background demo.','offline');}
    });
    window.scfdReceiveFcmToken = (token, error) => {
      $('nativeFcmToken').value = token || '';
      $('nativeFcmTokenHelp').textContent = error || 'Native token obtained. Share ONLY with your authorized Firebase project administrator; enroll the token for the right user.';
    };
    $('requestFcmToken').addEventListener('click', () => {
      if (window.AndroidAlerts && typeof window.AndroidAlerts.requestFcmToken === 'function') {
        $('nativeFcmTokenHelp').textContent = 'Requesting native FCM token…';
        window.AndroidAlerts.requestFcmToken();
      } else $('nativeFcmTokenHelp').textContent = 'Native FCM requires the v1.3 Android APK.';
    });
    $('enableNotifications').addEventListener('click',enableNotifications);
    $('soundEnabled').checked=state.soundEnabled;
    $('soundEnabled').addEventListener('change',e => {
      state.soundEnabled=!!e.target.checked;
      try{localStorage.setItem(STORAGE_SOUND,String(state.soundEnabled));}catch{}
      if(!state.soundEnabled && state.audioPlayer) state.audioPlayer.pause();
      showToast(state.soundEnabled?'Alert sounds are ON.':'Alert sounds are OFF.');
    });
    document.querySelectorAll('[data-test-sound]').forEach(button=>button.addEventListener('click',()=>testAlert(button.dataset.testSound)));
    if(hasAndroidAlerts()) {
      $('permissionText').textContent='Android notifications: tap Enable, then allow the phone permission.';
      $('pushText').textContent='Background push needs native Firebase setup. App-open notifications work in demo.';
    }
    $('connectFirebase').addEventListener('click',connectFirebase);
    $('disconnectFirebase').addEventListener('click',()=>disconnectFirebase());
    $('subscribePush').addEventListener('click',subscribePush);
    if ('Notification' in window && Notification.permission==='granted') {
      $('permissionText').textContent='Notifications are allowed on this browser.';
      $('enableNotifications').textContent='Enabled';
    }
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') refreshNativeBackgroundHistory();
    });
    window.addEventListener('focus',refreshNativeBackgroundHistory);
    refreshNativeBackgroundHistory();
    if('serviceWorker' in navigator && location.protocol!=='file:')registerWorker();
    setInterval(()=>{
      if(state.mode==='live')render();
    },5000);
    const hash=location.hash.replace('#','');
    if(['dashboard','alerts','settings'].includes(hash))gotoView(hash);
    render();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',setup);
  else setup();
})();
