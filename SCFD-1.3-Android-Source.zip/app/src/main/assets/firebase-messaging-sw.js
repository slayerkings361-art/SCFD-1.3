/*
 * Service worker for offline shell and Firebase Cloud Messaging background pushes.
 * IMPORTANT: config.js is shared by the web client and this worker.
 */
const APP_CACHE = 'smartcar-flood-defense-v1';
const FILES = ['./','./index.html','./styles.css','./app.js','./config.js','./manifest.json','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(APP_CACHE).then(cache=>cache.addAll(FILES)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==APP_CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET' || !event.request.url.startsWith(self.location.origin))return;
  event.respondWith(fetch(event.request).catch(()=>caches.match(event.request).then(r=>r||caches.match('./index.html'))));
});

try {
  importScripts('./config.js');
  if (self.SMARTCAR_FIREBASE_CONFIG?.projectId) {
    importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js');
    importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js');
    firebase.initializeApp(self.SMARTCAR_FIREBASE_CONFIG);
    firebase.messaging().onBackgroundMessage(payload => {
      const title = payload.data?.title || 'Smart Car Flood Alert';
      const options = {
        body: payload.data?.message || 'Your vehicle flood sensor detected rising water.',
        icon: './icons/icon-192.png',
        badge: './icons/icon-192.png',
        tag: `smartcar-${payload.data?.status || 'alert'}`,
        data: {url: './index.html#alerts'}
      };
      self.registration.showNotification(title,options);
    });
  }
} catch(error) { console.error('Firebase messaging worker could not initialize:',error); }
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const destination=new URL(event.notification.data?.url||'./index.html#alerts',self.location.href).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(async clients=>{
    for(const client of clients){if(client.url.startsWith(self.location.origin)){await client.focus();client.navigate(destination);return;}}
    return self.clients.openWindow(destination);
  }));
});
