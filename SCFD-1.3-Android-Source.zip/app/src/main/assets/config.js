/*
 * FIREBASE CONFIGURATION
 * 1. Open Firebase Console > Project Settings > Your apps > Web app.
 * 2. Copy the Firebase config object into SMARTCAR_FIREBASE_CONFIG below.
 * 3. Copy Web Push certificate (VAPID) public key into SMARTCAR_VAPID_KEY.
 * This config is PUBLIC client configuration: NEVER put admin secrets here.
 */
globalThis.SMARTCAR_FIREBASE_CONFIG = null;
/* Example:
globalThis.SMARTCAR_FIREBASE_CONFIG = {
  apiKey: '...',
  authDomain: 'your-project.firebaseapp.com',
  databaseURL: 'https://your-project-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'your-project',
  storageBucket: 'your-project.firebasestorage.app',
  messagingSenderId: '...',
  appId: '...'
};
*/
globalThis.SMARTCAR_VAPID_KEY = '';
