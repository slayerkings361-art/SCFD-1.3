# SCFD 1.3 - Android background flood alert prototype

**Status:** SOURCE READY FOR ANDROID STUDIO / GITHUB ACTIONS BUILD. The Android binary has NOT been compiled or installed in this session because the Android SDK and Gradle are unavailable. Do not rename any manually created APK to 1.3.

## What's new

- Keeps the SCFD v1.2 dashboard, sound test, sliders, local danger siren, and ESP32 firmware companion (see v1.2 project).
- Adds `BackgroundDemoService`, a user-triggered 29-second Android foreground test service. This service owns its own timer rather than relying on WebView JavaScript. It plays warning at 8 seconds (16 cm), danger at 16 seconds (32 cm), safe at 26 seconds (4 cm) and finishes at 29 seconds.
- Records native background demo events for the alert history when the UI returns. Starts a visible ongoing Android service notification with an emergency `Stop test` action. The demo uses Android `shortService`, intended only for short work, with a max-31-second partial wake lock to keep scheduled test timing while the screen is locked. This is NOT continuous background monitoring.
- Adds `FloodMessagingService` to show an Android notification with level-specific channel sound when a *valid real FCM data message* arrives for `car-001`. It is a receiver only until configured with a Firebase project and an authorized registration token.
- Demo notifications always say `SCFD DEMO` or `Simulated`, not real flood warnings.

## Build the standard APK

1. Extract the ZIP, open folder in Android Studio, install SDK 35 / JDK 17, and allow Gradle to sync.
2. Build > Build APK(s), or run `gradle assembleDebug` with Gradle 8.9 on a configured Android SDK workstation.
3. Install `app/build/outputs/apk/debug/app-debug.apk` on your Android device. If an older APK signed with a different key is installed, uninstall it first (back up any local data).
4. On Android 13+, open the app > Settings > Notifications > Enable and allow permission. Enable Alert sounds.
5. In Settings under Demo mode, tap `Start background test`. Lock the screen or leave the app; WARNING at 8 seconds, DANGER at 16, SAFE at 26. Service ends at 29 seconds. Test the physical phone's volume and DND settings. Do not force-stop the app.

Alternatively: push this folder to a GitHub repository (including hidden `.github` folder), select Actions > SCFD 1.3 Android APK > Run workflow, and download the **SCFD-1.3-debug-apk** artifact. Extract it to access `app-debug.apk`.

## REAL background flood alerts (not ready without configuration)

1. Create a Firebase Android app registered as `ph.smartcar.flooddefense`; save `google-services.json` as `app/google-services.json` (NEVER commit credentials or private Admin keys).
2. Configure the existing backend `backend/functions` and firmware from v1.2 with your Firebase project, internet, credentials, and sensor calibration.
3. In app > Settings > Get Android FCM token, copy the result, then **register the Android device's native FCM token for the correct authorized Firebase user** in `/devices/car-001/subscribers/<uid>/token` in the project's Realtime Database. This project intentionally does not expose an unauthenticated public registration endpoint or automatically enroll arbitrary users. This version displays a native token for admin pairing, but authenticated automatic enrollment is still TODO before general release. An FCM token used for web push is NOT interchangeable with the Android SDK's FCM token.
4. The cloud function requests Android `high` priority and sends Safe, Warning, and Danger transitions and the native `FloodMessagingService` receives valid data-only payloads. Realtime delivery is affected by internet, Google Play services, battery optimization, notification settings, and the Android lifecycle. FCM cannot guarantee alarms when app is force-stopped or without connectivity.
5. For actual safety, retain a local buzzer directly on ESP32; never rely on a phone notification alone.

## Important limitations

- No guarantee the demo service survives all OEM battery optimizations, force-stop, or reboot. `shortService` is deliberately short-lived and NOT a perpetual service.
- A 29-second background demo is not a real-time background sensor simulation. It produces scheduled synthetic alerts without the ESP32.
- FCM sound channel may be silenced by the phone user, notification permission, DND, or OEM behavior.
- Native push requires Google Services setup and account-specific token registration, which is NOT automated in this source.
- No physical phone testing or compiled APK verification occurred here.
- This is an educational prototype, NOT a certified life-safety device. Do not enter floodwater.

See `TESTING.md` for checks, and `backend/` for Firebase function.
